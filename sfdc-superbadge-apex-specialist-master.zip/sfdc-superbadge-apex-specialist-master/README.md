# sfdc-superbadge-apex-specialist

* resources
  * [Upsert with externalId in Apex](https://developer.salesforce.com/docs/atlas.en-us.apexcode.meta/apexcode/langCon_apex_dml_examples_upsert.htm)
  * [Allow Reparenting Options for Master-Detail records](https://www.packtpub.com/mapt/book/application_development/9781784397562/3/ch03lvl1sec46/master-detail-relationship-options)
