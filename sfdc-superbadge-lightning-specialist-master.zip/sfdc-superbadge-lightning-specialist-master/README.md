# sfdc-superbadge-lightning-specialist

* [refer to this github repo](https://github.com/detonation0/lightning-component-framework-specialist-superbadge)
